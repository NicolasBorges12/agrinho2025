let trator;
let tratorX;
let tratorY;
let tratorLargura = 80;
let tratorAltura = 50;
let velocidadeTrator = 5;

let cenouras = [];
let intervaloCenoura = 60; // Quantos frames até uma nova cenoura aparecer
let ultimoSpawnCenoura = 0;

let pontuacao = 0;

let imgTrator;
let imgCenoura;
let imgFundo;

function preload() {
  // Você pode usar imagens ou formas simples.
  // Para usar imagens, faça o upload para o seu sketch do p5.js
  // e ajuste os caminhos abaixo.
  // Exemplo:
  // imgTrator = loadImage('assets/trator.png');
  // imgCenoura = loadImage('assets/cenoura.png');
  // imgFundo = loadImage('assets/fundo.png');
}

function setup() {
  createCanvas(800, 600);
  tratorX = width / 2 - tratorLargura / 2;
  tratorY = height - tratorAltura - 20; // Perto da parte inferior da tela
  rectMode(CORNER); // Desenha retângulos do canto superior esquerdo
}

function draw() {
  // Desenha o fundo
  if (imgFundo) {
    image(imgFundo, 0, 0, width, height);
  } else {
    background(135, 206, 235); // Céu azul
    fill(139, 69, 19); // Chão marrom
    rect(0, height - 100, width, 100);
  }

  // Desenha e atualiza o trator
  desenhaTrator();
  atualizaTrator();

  // Gera novas cenouras
  if (frameCount - ultimoSpawnCenoura > intervaloCenoura) {
    cenouras.push(new Cenoura());
    ultimoSpawnCenoura = frameCount;
  }

  // Desenha e atualiza as cenouras
  for (let i = cenouras.length - 1; i >= 0; i--) {
    cenouras[i].mover();
    cenouras[i].desenhar();

    // Verifica colisão com o trator
    if (cenouras[i].colide(tratorX, tratorY, tratorLargura, tratorAltura)) {
      pontuacao++;
      cenouras.splice(i, 1); // Remove a cenoura coletada
    } else if (cenouras[i].offscreen()) {
      cenouras.splice(i, 1); // Remove cenouras que saíram da tela
    }
  }

  // Exibe a pontuação
  fill(0); // Cor preta para o texto
  textSize(24);
  textAlign(LEFT, TOP);
  text('Cenouras: ' + pontuacao, 10, 10);
}

function desenhaTrator() {
  if (imgTrator) {
    image(imgTrator, tratorX, tratorY, tratorLargura, tratorAltura);
  } else {
    // Desenha um trator simples (retângulo e rodas)
    fill(0, 150, 0); // Corpo verde do trator
    rect(tratorX, tratorY, tratorLargura, tratorAltura - 10); // Corpo principal
    rect(tratorX + tratorLargura / 4, tratorY - 15, tratorLargura / 2, 20); // Cabine

    fill(50); // Cor das rodas
    ellipse(tratorX + tratorLargura * 0.2, tratorY + tratorAltura - 10, 20, 20); // Roda esquerda
    ellipse(tratorX + tratorLargura * 0.8, tratorY + tratorAltura - 10, 25, 25); // Roda direita
  }
}

function atualizaTrator() {
  if (keyIsDown(LEFT_ARROW)) {
    tratorX -= velocidadeTrator;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    tratorX += velocidadeTrator;
  }

  // Limita o trator à tela
  tratorX = constrain(tratorX, 0, width - tratorLargura);
}

// Classe para as Cenouras
class Cenoura {
  constructor() {
    this.x = random(width);
    this.y = -20; // Começa acima da tela
    this.largura = 20;
    this.altura = 40;
    this.velocidade = random(1, 3); // Velocidade de queda
  }

  mover() {
    this.y += this.velocidade;
  }

  desenhar() {
    if (imgCenoura) {
      image(imgCenoura, this.x, this.y, this.largura, this.altura);
    } else {
      // Desenha uma cenoura simples
      fill(255, 165, 0); // Laranja
      ellipse(this.x, this.y, this.largura, this.altura);
      fill(0, 100, 0); // Verde (folhas)
      triangle(this.x, this.y - this.altura / 2,
               this.x - this.largura / 4, this.y - this.altura / 2 - 10,
               this.x + this.largura / 4, this.y - this.altura / 2 - 10);
    }
  }

  colide(tratorX, tratorY, tratorLargura, tratorAltura) {
    // Verifica colisão usando retângulos (para simplificar)
    return (
      this.x < tratorX + tratorLargura &&
      this.x + this.largura > tratorX &&
      this.y < tratorY + tratorAltura &&
      this.y + this.altura > tratorY
    );
  }

  offscreen() {
    return this.y > height; // Cenoura saiu da tela por baixo
  }
}